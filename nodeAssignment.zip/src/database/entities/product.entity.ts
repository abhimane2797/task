import { Exclude } from 'class-transformer';
import { BaseEntity, Column, Entity } from 'typeorm';
import { PrimaryGeneratedColumn } from 'typeorm/decorator/columns/PrimaryGeneratedColumn';

@Entity('products')
export class ProductEntity extends BaseEntity {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({
    type: 'varchar',
    name: 'name',
    nullable: false,
  })
  name: string;

  @Column({
    type: 'varchar',
    name: 'discription',
    nullable: false,
  })
  discription: string;

  @Column({
    type: 'varchar',
    name: 'price',
    nullable: false,
  })
  price: number;
}
