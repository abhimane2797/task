import { ProductEntity } from "./product.entity";

export const entities = [
    ProductEntity
];

export * from './product.entity';