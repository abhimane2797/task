import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { AppDataSource } from '../config/database.config';
import { ProductsModule } from './products/products.module';

@Module({
    imports: [
        TypeOrmModule.forRoot(AppDataSource.options),
        ProductsModule,
        
    ],
    providers: []
})
export class ApiModule { }
