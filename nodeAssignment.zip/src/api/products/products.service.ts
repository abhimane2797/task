import { Injectable } from '@nestjs/common';
import { CreateProductDto } from './dto/create-product.dto';
import { UpdateProductDto } from './dto/update-product.dto';
import { InjectRepository } from '@nestjs/typeorm';
import { ProductEntity } from 'src/database/entities';
import { Repository } from 'typeorm';

@Injectable()
export class ProductsService {
  constructor(
    @InjectRepository(ProductEntity)
    private readonly productRepository: Repository<ProductEntity>,
  ) {}
  async create(createProductDto: CreateProductDto) {
    const { name, discription, price } = createProductDto;
    const product = await this.productRepository.create({
      name,
      discription,
      price,
    });
    await this.productRepository.save(product);

    return 'This action adds a new product';
  }

  findAll() {
    return this.productRepository.find({ skip: 0, take: 20 });
  }

  async findOne(id: string) {
  await this.productRepository.findOneBy({id});
    return this.productRepository.findOneBy({id});
  }

  update(id: number, updateProductDto: UpdateProductDto) {
    return `This action updates a #${id} product`;
  }

  async remove(id: string) {
    await this.productRepository.delete(id);
    return 'User Deleted Successfully';
  }
}
