export interface Message {
  ProductName: string;
  description: string;
  price: string;
  id: number;
}

// const API_URL = `http://localhost:4000/api/products`;

// function getData() {
  
//   fetch(API_URL)
//     .then(res => res.json())
//     .then(json => setIdData(json))
// }

const messages: Message[] = [
  {
    ProductName: 'Apple',
    description: 'Fressh Fruit',
    price: '40',
    id: 0
  },
  {
    ProductName: 'Mango',
    description: 'Alphonso',
    price: '800',
    id: 1
  },
  {
    ProductName: 'Banana',
    description: 'Fressh Fruit',
    price: '80',
    id: 2
  },
  
];

export const getMessages = () => messages;

export const getMessage = (id: number) => messages.find(m => m.id === id);
