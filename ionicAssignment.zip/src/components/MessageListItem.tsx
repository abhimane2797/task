// import {
//   IonItem,
//   IonLabel,
//   IonNote
// } from '@ionic/react';
// import { Message } from '../data/messages';
// import './../../public/css/MessagelistItem.css';
// import { IonCol, IonGrid, IonRow } from '@ionic/react';
// import Global from "../image/global.png";
// import { BASE_URL } from "../../src/global";
// import { IonCard, IonCardContent, IonCardHeader, IonCardSubtitle, IonCardTitle } from '@ionic/react';

// // const axios = require("axios");

// interface MessageListItemProps {
//   message: Message;
// }


// const MessageListItem: React.FC<MessageListItemProps> = ({ message }) => {
//   return (
//     <>
//       <IonItem >
//         {/* <div slot="start" className="dot dot-unread"></div> */}
//         {/* <IonLabel className="ion-text-wrap">
        
//         {message.ProductName}
//       </IonLabel> */}
//         <IonGrid>
//           <IonRow>
//             <IonCol>
          
//               <IonCard  class='hover'  routerLink={`/message/${message.id}`} >
//                 <IonCardHeader>
//                   <IonCardTitle>{message.ProductName}</IonCardTitle>
//                   <IonCardSubtitle>{message.description}</IonCardSubtitle>
//                 </IonCardHeader>
//                 <IonCardContent>
//                   {message.price}₹
//                 </IonCardContent>
//               </IonCard>
//             </IonCol>
            
//           </IonRow>
//         </IonGrid>


//       </IonItem>

//     </>
//   );
// };

// export default MessageListItem;
