const URL = "localhost:4000/api/products";
export const BASE_URL = `https://${URL}/`;
export const DOMAIN = `https://${URL}/`;
export const MAX_COLS = 30;
export const ID_BASE = 650;
export const SRF_ID_BASE = 650;

