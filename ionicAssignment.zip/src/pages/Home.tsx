// import MessageListItem from '../components/MessageListItem';
import { useState, useEffect } from 'react';
import { Message, getMessages } from '../data/messages';
import {
  IonBackButton,
  IonButtons,
  IonContent,
  IonHeader,
  IonIcon,
  IonItem,
  IonTitle,
  IonLabel,
  IonNote,
  IonCol,
  IonPage,
  IonToolbar,
  useIonViewWillEnter,
  IonModal,
  IonInput,
  IonGrid,
  IonRow,
  IonCard,
  IonButton,
  IonItemDivider,
  IonRefresher,
  IonRefresherContent,
  IonList,
  IonCardHeader,
  IonCardTitle,
  IonCardSubtitle,
  IonCardContent
} from '@ionic/react';
import { IonBadge } from '@ionic/react';

import { bag, cart, cartOutline, personCircle, close } from 'ionicons/icons';

import './../../public/css/Home.css';

const Home: React.FC = () => {

  const [messages, setMessages] = useState<Message[]>([]);
  const [isOpen, setIsOpen] = useState(false);
  const [array, setArr] = useState<any[]>([]);
  const [data, setData] = useState<any[]>([]);
  const [total, setTotal] = useState<any[]>([]);


  const API_URL = `http://localhost:4000/api/products`;

  function getData() {
    fetch(API_URL)
      .then(res => res.json())
      .then(json => setData(json))
  }

  function addition() {
    const products =localStorage.getItem('products')

      // console.log(JSON.parse(products))
      const sum = JSON.parse(products);
      console.log(sum[0].Price)

      let add = 0;

      sum.forEach((s: any) => {
        add += s.Price;
      });
     setTotal(add)
      console.log("add",add)
  }

  useIonViewWillEnter(() => {
    const msgs = getMessages();
    setMessages(msgs);
    getData();
    addition();
    // console.log(msgs)
  });

  const refresh = (e: CustomEvent) => {
    setTimeout(() => {
      e.detail.complete();
    }, 3000);
  };

  useEffect(() => {

    const products = localStorage.getItem('products');
    if (products) {
      setArr(JSON.parse(products));
    }

  }, []);


  return (
    <IonPage id="home-page">
      <IonHeader>
        <IonToolbar>
          <IonTitle className='cart-left'>Products</IonTitle>
          <IonTitle className='cart-right' onClick={() => setIsOpen(true)}><IonIcon className='cart' icon={cart}></IonIcon></IonTitle>
          <IonModal isOpen={isOpen}>
            <IonHeader>
              <IonToolbar>
                <IonTitle>Cart</IonTitle>
                <IonButtons slot="end">
                  <IonButton className='closeButton' onClick={() => setIsOpen(false)}><IonIcon color="danger" icon={close}></IonIcon></IonButton>
                </IonButtons>
              </IonToolbar>
            </IonHeader>

            <IonContent className="ion-padding">
              <IonCard>
                <IonGrid>
                  <IonRow>
                    <IonCol>
                      <h1>Product</h1>
                    </IonCol>
                    <IonCol>
                      <h1>Price</h1>
                    </IonCol>
                    <IonCol>
                      <h1>Quantity</h1>
                    </IonCol>
                  </IonRow>
                </IonGrid>
                <IonItemDivider></IonItemDivider>
                <IonGrid>
                  {array?.map((row, index) => (
                    <IonRow>
                      <IonCol>
                        {array ?
                          (<h5> {row.id}</h5>)
                          :
                          (<div>Message not found</div>)
                        }
                      </IonCol>
                      <IonCol>
                        {array ?
                          (<h5>{row.Price} ₹</h5>)
                          :
                          (<div>Message not found</div>)
                        }
                      </IonCol>
                      <IonCol>
                        {array ?
                          (<h5>{row.Quantity}</h5>)
                          :
                          (<div>Message not found</div>)
                        }
                      </IonCol>
                    </IonRow>
                  ))}
                </IonGrid>
                <IonGrid>
                  <IonRow>
                    <IonCol>

                    </IonCol>
                    <IonCol>
                    <h2 className="total">Total : {total}</h2>
                    </IonCol>
                    <IonCol>
                      
                    </IonCol>
                  </IonRow>
                </IonGrid>
               

              </IonCard>


            </IonContent>
          </IonModal>
        </IonToolbar>
      </IonHeader>
      <IonContent fullscreen>
        <IonRefresher slot="fixed" >
          <IonRefresherContent></IonRefresherContent>
        </IonRefresher>

        <IonHeader collapse="condense">
          <IonToolbar>
            <IonTitle size="large">
              Inbox
            </IonTitle>
          </IonToolbar>
        </IonHeader>

        <IonList>
          {data?.map(d =>

            <IonCard routerLink={`/message/${d.id}`}>
              <IonList>
                <IonItem>
                  <IonBadge slot="start">{d.id}</IonBadge>
                  <IonGrid>
                    <IonRow>
                      <IonCol>

                        <IonCardHeader>
                          <IonCardTitle>Product name : {d.name}</IonCardTitle>
                          <IonCardSubtitle>Description : {d.discription}</IonCardSubtitle>

                        </IonCardHeader>
                        <IonCardContent>
                          Price : {d.price}₹
                        </IonCardContent>
                      </IonCol>

                    </IonRow>
                  </IonGrid>
                </IonItem>
              </IonList>
            </IonCard>
          )}

        </IonList>
      </IonContent>
    </IonPage>
  );
};

export default Home;
