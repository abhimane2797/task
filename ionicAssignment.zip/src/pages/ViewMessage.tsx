import { useState, useRef, useEffect } from 'react';
import { Message, getMessage } from '../data/messages';
import {
  IonBackButton,
  IonButtons,
  IonContent,
  IonHeader,
  IonIcon,
  IonItem,
  IonTitle,
  IonLabel,
  IonNote,
  IonCol,
  IonPage,
  IonToolbar,
  useIonViewWillEnter,
  IonModal,
  IonInput,
  IonGrid,
  IonRow,
  IonItemDivider
} from '@ionic/react';
import { bag, cart, cartOutline, personCircle, close } from 'ionicons/icons';
import { useParams } from 'react-router';
import './../../public/css/viewMessage.css';
import { IonCard, IonCardContent, IonCardHeader, IonCardSubtitle, IonCardTitle } from '@ionic/react';
import { IonButton } from '@ionic/react';



function ViewMessage() {
  const [idData, setIdData] = useState<any[]>([]);
  const [message, setMessage] = useState<Message>([]);
  const [isOpen, setIsOpen] = useState(false);
  const [items, setItems] = useState([]);
  let [num, setNum] = useState(0);
  const params = useParams<{ id: string }>();

  const API_URL = `http://localhost:4000/api/products/` + params.id;

  function getData() {
    fetch(API_URL)
      .then(res => res.json())
      .then(json => setIdData(json))
      // .then(json => console.log(json))
  }



  function setData() {
    let arr = [];
    const products = localStorage.getItem('products');
    if (products) {
      arr = JSON.parse(products);
    }
    const index = arr.findIndex((ele: any) => ele.id === idData?.id);
    if (index !== -1) {
      arr[index].Quantity = num;
      arr[index].Price = idData?.price * num;
    } else {
      arr.push({
        id: idData?.id,
        Quantity: num,
        Price: idData?.price * num,
        Description: idData?.description,
        name: idData?.ProductName
      });
    }

    localStorage.setItem('products', JSON.stringify(arr));
  }



  let incNum = () => {
    if (num < 10) {
      setNum(Number(num) + 1);
    }
  };
  let decNum = () => {
    if (num > 0) {
      setNum(num - 1);
    }
  }

  let handleChange = (e) => {
    setNum(e.target.value);
  }

  const setCount = (msg: any) => {
    const products = localStorage.getItem('products');
    if (products) {
      const arr = JSON.parse(products);
      const index = arr.findIndex((item: any) => item.id === msg?.id);
      // console.log('data', index, arr, msg)
      if (index !== -1) {
        console.log('Test data', arr[index].Quantity)
        return setNum(arr[index].Quantity);
      }
    }
    setNum(5);
  }


  useIonViewWillEnter(() => {
    const msg = getMessage(parseInt(params.id, 10));
    setMessage(msg);
    setCount(msg);
    getData();
    getProduct();
  });



  return (
    <IonPage id="view-message-page">
      <IonHeader translucent>
        <IonToolbar>
          <IonButtons slot="start">
            <IonBackButton text="Product" defaultHref="/home"></IonBackButton>
          </IonButtons>
        </IonToolbar>
      </IonHeader>

      <IonContent fullscreen>
        
          <IonCard class='hover'  >

            <IonCardHeader>
              <IonCardTitle>{idData.name}</IonCardTitle>
              <IonCardSubtitle>{idData.description}</IonCardSubtitle>

              <IonCardSubtitle>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</IonCardSubtitle>
            </IonCardHeader>
            <IonCardContent>
              {idData.price}₹
            </IonCardContent>
          </IonCard>
       
      </IonContent>
      <IonButton expand="block" size="small" onClick={() => setIsOpen(true)} ><IonIcon icon={cart}></IonIcon>Add To Cart</IonButton>
      <IonModal isOpen={isOpen}>
        <IonHeader>
          <IonToolbar>
            <IonTitle>Cart</IonTitle>
            <IonButtons slot="end">
              <IonButton className='closeButton' onClick={() => setIsOpen(false)}><IonIcon color="danger" icon={close}></IonIcon></IonButton>
            </IonButtons>
          </IonToolbar>
        </IonHeader>

        <IonContent className="ion-padding">
          <IonCard>
            <IonGrid>
              <IonRow>
                <IonCol>
                  <h1>Product</h1>
                </IonCol>
                <IonCol>
                  <h1>Price</h1>
                </IonCol>
                <IonCol>
                  <h1>Quantity</h1>
                </IonCol>
              </IonRow>
            </IonGrid>
            <IonItemDivider></IonItemDivider>
            <IonGrid>
              <IonRow>
                <IonCol>
                  {idData ?
                    (<h5>1. {idData.name}</h5>)
                    :
                    (<div>Message not found</div>)
                  }
                </IonCol>
                <IonCol>
                  {idData ?
                    (<h5>{idData.price} ₹</h5>)
                    :
                    (<div>Message not found</div>)
                  }
                </IonCol>
                <IonCol>
                  <div className="col-xl-1">
                    <div className="input-group">
                      <div className="input-group-prepend">
                        <IonButton className="btn btn-outline-primary" color="dark" type="button" onClick={decNum}>-</IonButton>
                      </div>
                      <IonInput type="text" className="form-control" value={num} onChange={handleChange} />
                      <div className="input-group-prepend">
                        <IonButton class="btn btn-outline-primary" color="dark" type="button" onClick={incNum}>+</IonButton>
                      </div>
                    </div>
                  </div>
                </IonCol>
              </IonRow>
            </IonGrid>
            <div className="total">
              <h2>Total : {num * idData?.price}</h2>
            </div>

          </IonCard>

          <IonButton expand="block" color="warning"  onClick={() => setData() }>Checkout</IonButton>
        </IonContent>
      </IonModal>
    </IonPage>
  );
}

export default ViewMessage;
